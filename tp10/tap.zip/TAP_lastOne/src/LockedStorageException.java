public class LockedStorageException extends Exception {
    private static final long serialVersionUID = 1L;
}
